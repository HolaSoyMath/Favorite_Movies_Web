import { HTMLAttributes, useState } from "react";
import { Ratings } from "../atoms/Rating";
import React from 'react'

export interface ScoreAndFavoriteProps 
    extends HTMLAttributes<HTMLDivElement>{
    functionRating: React.Dispatch<React.SetStateAction<number>>
    valueRating: number
    functionFavorite: React.Dispatch<React.SetStateAction<number>>
    valueFavorite: number
    className?: string
}

export function ScoreAndFavorite({functionRating, valueRating, functionFavorite, valueFavorite, className, ...props}: ScoreAndFavoriteProps) {

    const [ratingStar, setRatingStar] = useState(0)
    const [ratingHeart, setRatingHeart] = useState(0)

    return(
        <div style={{display: "flex"}} className={className} {...props}>
            <Ratings type="star" value={ratingStar} onChange={setRatingStar} quantity={5} />
            <Ratings type="heart" value={ratingHeart} onChange={setRatingHeart} quantity={1}/>
        </div>
    )
}
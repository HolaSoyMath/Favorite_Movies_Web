import React, { HTMLAttributes } from "react";
import { InfoCardTop } from "../atoms/InfoCardTop/InfoCardTop";

export interface MovieCardProps extends HTMLAttributes<HTMLDivElement> {
  idMovie: string | number
  genre: string
  year: string
  movieTitle: string
  description: string
  poster: string
  rating: number
  favorite: number
  className?: string
}

export function MovieCard ({ idMovie, genre, year, movieTitle, description, poster, rating, favorite, className, ...props }: MovieCardProps) {
  return (
      <div id={idMovie.toString()} className="h-[70px] w-[70px]">
        
      </div>
  );
}

TitleCard.displayName = "TitleCard";
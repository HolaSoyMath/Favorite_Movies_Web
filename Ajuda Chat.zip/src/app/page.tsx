"use client"

import { useState } from "react";
import { InfoCardTop } from "@/components/atoms/InfoCardTop/InfoCardTop";
import { TextCard } from "@/components/atoms/TextCard/TextCard";

//Rating
import { Ratings } from "@/components/atoms/Ratings/Rating";

export default function Home() {
  const [ratingStar, setRatingStar] = useState(0)
  const [ratingHeart, setRatingHeart] = useState(0)

  return (
    <div className="grid grid-rows-[20px_1fr_20px] items-center justify-items-center min-h-screen p-8 pb-20 gap-16 sm:p-20 font-[family-name:var(--font-geist-sans)]">
      <InfoCardTop text={"Action/Adventure"} variant="category"/>
      <InfoCardTop text={"1999"} />

      <div style={{width: "50%", height: "100px", padding:"none", background: "blue"}}>
        <TextCard> Teste de título </TextCard>
        <TextCard variant="description">Com saudade do tempo em que era um verdadeiro ogro, Shrek assina um contrato enfeitiçado com Rumpelstiltskin e de repente puf! Em um instante, tudo e todos se transformam. De repente Burro não se lembra de seu melhor amigo, Fiona agora é uma valente princesa guerreira e Gato de Botas é só um gato gordo! Juntos </TextCard>
      </div>

      teste Star: {ratingStar}
      teste Heart: {ratingHeart}
      <div style={{display: "flex"}}>
        <Ratings type="star" style={{height: "100px", width: "100px" }} value={ratingStar} onChange={setRatingStar} quantity={5} />
        <Ratings type="heart" style={{height: "50px", width: "50px" }} value={ratingHeart} onChange={setRatingHeart} quantity={1} />
      </div>

    </div>
  );
}
